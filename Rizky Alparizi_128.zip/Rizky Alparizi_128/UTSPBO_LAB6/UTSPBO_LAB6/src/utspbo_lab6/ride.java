/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utspbo_lab6;

/**
 *
 * @author Acer
 */
public class ride {
    int kecepatan;
    int arah;
    int kecepatanmaks;
    boolean bergerak;
    boolean meledak;


    public ride(){
        kecepatan = 0;
        arah = 0;
        bergerak = false;
        kecepatanmaks = 700;
    }

    public int getkecepatan() {
        return kecepatan;
    }

    public void setkecepatan(int kecepatan) {
        if (kecepatan >= 0 && kecepatan <= kecepatanmaks) {
            this.kecepatan = kecepatan;
            if (bergerak) {
                updatearah();
            }
        }
    }

    public int getarah() {
        return arah;
    }

    public void setarah(int arah) {
        if (arah >= 0 && arah <= 360) {
            this.arah = arah;
            if (bergerak) {
                updatearah();
            }
        }
    }

    public boolean bergerak() {
        return bergerak;
    }

    public void start() {
        bergerak = true;
        updatearah();
    }

    public void stop() {
        bergerak = false;
    }

    public void setkecepatanmaks(int kecepatanmaks) {
        this.kecepatanmaks = kecepatanmaks;
    }

    public void useNitrous() {
        if (kecepatan < kecepatanmaks) {
            kecepatan = kecepatan*10;
            if (kecepatan > kecepatanmaks) {
                System.out.println("Kecepatan sudah maksimal");
                kecepatan = kecepatanmaks;
            }
        }
        if (bergerak) {
            updatearah();
        }
    }

    public void meledak() {
        if (kecepatan > kecepatanmaks) {
            meledak = true;
            
        }
    }

    public void updatearah() {
        if (kecepatan == 0) {
            return;
        }
        int newarah = arah + kecepatan / 10;
        if (newarah > 360) {
            newarah = newarah - 360;
        }
        arah = newarah;
    }
}    
