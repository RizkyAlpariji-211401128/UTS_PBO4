/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package utspbo_lab6;


public class remotecon {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          ride myCar = new ride();
        
        myCar.start();
        myCar.setkecepatan(50);
        myCar.setarah(180);
        
        
        System.out.println("Kecepatan :" + myCar.getkecepatan() + " KM/H");
        System.out.println("Arah :  " + myCar.getarah());
       
        
        myCar.useNitrous();
        
        System.out.println("Kecepatan anda bertambah menjadi: " + myCar.getkecepatan() + " KM/H");
        System.out.println("Arah anda menjadi:  " + myCar.getarah());
       
        myCar.meledak();

        System.out.println("Mobil anda telah meledak");
        System.out.println("=======================");
        System.out.println("Stats");
        System.out.println("=======================");
        System.out.println("Kecepatan terakhir anda " + myCar.getkecepatan() + " KM/H");
        System.out.println("Arah terakhir anda " + myCar.getarah());
        
    }
    
}
