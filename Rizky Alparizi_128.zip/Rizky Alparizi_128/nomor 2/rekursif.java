public class rekursif {
    
    public int faktorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * faktorial(n - 1);
        }
    }

    public int fibonacci(int n) {
        if (n == 0 || n == 1) {
            return n;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void main(String[] args) {
        rekursif rp = new rekursif();
        int n = 4;
        int hasilfk = rp.faktorial(n);
        int hasilfb = rp.fibonacci(n);
        System.out.println("hasil faktorial dari " + n + " adalah " + hasilfk);
        System.out.println("hasil fibonacci dari " + n + " adalah " + hasilfb);
    }
}